# Function to create a special matrix object that can cache its inverse
makeCacheMatrix <- function(mat = matrix()) {
  inverse <- NULL
  
  # Function to set the matrix
  setMatrix <- function(newMatrix) {
    mat <<- newMatrix
    inverse <<- NULL
  }
  
  # Function to get the matrix
  getMatrix <- function() {
    mat
  }
  
  # Function to get the cached inverse or compute and cache the inverse
  getInverse <- function() {
    if (is.null(inverse)) {
      message("Computing inverse and caching")
      inverse <- solve(mat)
    }
    return(inverse)
  }
  
  # Return a list of functions
  list(setMatrix = setMatrix, getMatrix = getMatrix, getInverse = getInverse)
}

# Function to compute the inverse of the special matrix object
cacheSolve <- function(cacheMatrix) {
  cacheInverse <- cacheMatrix$getInverse()
  return(cacheInverse)
}

# Example usage:
# Create a matrix
A <- matrix(c(4, 2, 1, 3), nrow = 2, ncol = 2, byrow = TRUE)

# Create a cache matrix object
cacheA <- makeCacheMatrix(A)

# Compute and cache the inverse
cacheSolve(cacheA)
# Output: Computing inverse and caching
#        [,1]  [,2]
# [1,]  0.6 -0.2
# [2,] -0.4  0.4

# Retrieve the cached inverse without recomputing
cacheSolve(cacheA)
# Output: Getting cached inverse
#        [,1]  [,2]
# [1,]  0.6 -0.2
# [2,] -0.4  0.4
